#include "stdafx.h"
#include "CxNtfsUtil.h"
#include <assert.h>
#include "MD5/Global.h"
#include "MD5/MD5.h"
#include "SHA256/KISA_SHA256.h"
#include <strsafe.h>
#include <Shlwapi.h>

#pragma comment(lib, "libjsoncpp.lib")

#ifndef FlagOn
#define FlagOn(_F,_SF)        ((_F) & (_SF))
#endif

CxNtfsUtil::CxNtfsUtil()
{
}


CxNtfsUtil::~CxNtfsUtil()
{
}

BOOL		CxNtfsUtil::OnFileHashCommand(X_NTFSPARSER_OPTION&	Option, OUT Json::Value& result)
{
	BOOL		bResult = FALSE;
	WCHAR		szMd5[X_MD5_LENGTH] = { 0, };
	WCHAR		szSha256[X_SHA256_LENGTH] = { 0, };
	LARGE_INTEGER	 FileSize = { 0, };

	result["command"] = WideToAnsi(Option.Command.c_str());

	bResult = xHashFile(Option.FilePath1.c_str(), szMd5, _countof(szMd5), szSha256, _countof(szSha256), &FileSize);
	if (FALSE == bResult)
	{
		result["success"] = false;
		goto FINAL;
	}
	
	result["success"] = true;

	result["MD5"] = WideToAnsi(szMd5);
	result["SHA256"] = WideToAnsi(szSha256);
	result["FileSize"] = FileSize.QuadPart;
	result["FilePath"] = WideToAnsi(Option.FilePath1.c_str());

FINAL:

	return		bResult;
}

BOOL		CxNtfsUtil::OnDumpFileCommand(X_NTFSPARSER_OPTION&	Option, OUT Json::Value& result)
{
	BOOL		bResult = FALSE;
	BOOL		FailIfExists = FALSE;
	
	result["command"] = WideToAnsi(Option.Command.c_str());

	if (FlagOn(Option.Flag, X_NTFS_OPTION_FAIL_IF_EXISTS))
	{
		FailIfExists = TRUE;
	}

	bResult = xDumpFile(Option.FilePath1.c_str(), Option.FilePath2.c_str(), FailIfExists);
	if (FALSE == bResult)
	{
		result["success"] = false;
		goto FINAL;
	}

	result["success"] = true;
	result["FilePath"] = WideToAnsi(Option.FilePath1.c_str());
	result["dumppath"] = WideToAnsi(Option.FilePath2.c_str());
	
FINAL:

	return		bResult;
}

BOOL		CxNtfsUtil::OnFileListCommand(X_NTFSPARSER_OPTION&	Option, OUT Json::Value& result)
{
	BOOL		bResult = FALSE;
	BOOL		FailIfExists = FALSE;
	WIN32_FIND_DATAW	FindData = { 0, };
	LARGE_INTEGER		FileSize = { 0, };

	result["command"] = WideToAnsi(Option.Command.c_str());

	bResult = xPathFileExists(Option.FilePath1.c_str(), &FindData);
	if (FALSE == bResult)
	{
		result["success"] = false;
		goto FINAL;
	}

	result["success"] = true;
	result["FilePath"] = WideToAnsi(Option.FilePath1.c_str());
	result["dumppath"] = WideToAnsi(Option.FilePath2.c_str());

	FileSize.LowPart = FindData.nFileSizeLow;
	FileSize.HighPart = FindData.nFileSizeHigh;

	result["FileSize"] = FileSize.QuadPart;

	result["dwFileAttributes"] = (UINT)FindData.dwFileAttributes;

	LARGE_INTEGER		CreationTime = { FindData.ftCreationTime.dwLowDateTime, FindData.ftCreationTime.dwHighDateTime };
	result["ftCreationTime"] = CreationTime.QuadPart;

	LARGE_INTEGER		LastAccessTime = { FindData.ftLastAccessTime.dwLowDateTime, FindData.ftLastAccessTime.dwHighDateTime };
	result["ftLastAccessTime"] = LastAccessTime.QuadPart;

	LARGE_INTEGER		LastWriteTime = { FindData.ftLastWriteTime.dwLowDateTime, FindData.ftLastWriteTime.dwHighDateTime };
	result["ftLastWriteTime"] = LastWriteTime.QuadPart;

	result["cFileName"] = WideToAnsi(FindData.cFileName);
	result["cAlternateFileName"] = WideToAnsi(FindData.cAlternateFileName);

FINAL:

	return		bResult;
}

Json::Value		CxNtfsUtil::FileInfoToJson(const WCHAR* pszFilePath, WIN32_FIND_DATAW& FindData)
{
	Json::Value		FileInfo;
	LARGE_INTEGER		FileSize = { 0, };

	FileInfo["FilePath"] = WideToAnsi(pszFilePath);

	FileSize.LowPart = FindData.nFileSizeLow;
	FileSize.HighPart = FindData.nFileSizeHigh;

	FileInfo["FileSize"] = FileSize.QuadPart;

	FileInfo["dwFileAttributes"] = (UINT)FindData.dwFileAttributes;

	LARGE_INTEGER		CreationTime = { FindData.ftCreationTime.dwLowDateTime, FindData.ftCreationTime.dwHighDateTime };
	FileInfo["ftCreationTime"] = CreationTime.QuadPart;

	LARGE_INTEGER		LastAccessTime = { FindData.ftLastAccessTime.dwLowDateTime, FindData.ftLastAccessTime.dwHighDateTime };
	FileInfo["ftLastAccessTime"] = LastAccessTime.QuadPart;

	LARGE_INTEGER		LastWriteTime = { FindData.ftLastWriteTime.dwLowDateTime, FindData.ftLastWriteTime.dwHighDateTime };
	FileInfo["ftLastWriteTime"] = LastWriteTime.QuadPart;

	FileInfo["cFileName"] = WideToAnsi(FindData.cFileName);
	FileInfo["cAlternateFileName"] = WideToAnsi(FindData.cAlternateFileName);

	return FileInfo;

}

BOOL		CxNtfsUtil::OnFileExistCommand(X_NTFSPARSER_OPTION&	Option, OUT Json::Value& result)
{
	BOOL		bResult = FALSE;
	WIN32_FIND_DATAW	FindData = { 0, };
	LARGE_INTEGER		FileSize = { 0, };

	result["command"] = WideToAnsi(Option.Command.c_str());

	bResult = xPathFileExists(Option.FilePath1.c_str(), &FindData);
	if (FALSE == bResult)
	{
		result["success"] = false;
		goto FINAL;
	}

	result["success"] = true;
	result["FilePath"] = WideToAnsi(Option.FilePath1.c_str());
	result["ApiResult"] = (bool)PathFileExists(Option.FilePath1.c_str());

	result["FileInfo"].append(FileInfoToJson(Option.FilePath1.c_str(), FindData));

FINAL:

	return		bResult;
}

BOOL		CxNtfsUtil::xHashFile(IN LPCWSTR lpszPath, WCHAR* pszMd5, ULONG cchMd5, WCHAR* pszSha256, ULONG cchSha256, OPTIONAL LARGE_INTEGER* FileSize)
{
	CNTFSHelper::NTFS_HANDLE hSrcFile = INVALID_HANDLE_VALUE_NTFS;
	BOOL			bRetValue = FALSE;
	CHAR*			pBuffer = NULL;
	DWORD			cbBytesRead = 0;
	DWORD			cbBytesToRead = 1024;
	BOOL			bResult = FALSE;
	SHA256_INFO		info;
	MD5_CTX			context;
	unsigned char	DigestSha256[SHA256_DIGEST_VALUELEN];
	unsigned char	DigestMd5[16];
	BOOL			bInit = FALSE;

	if (NULL == lpszPath)
	{
		return bRetValue;
	}

	do
	{
		pBuffer = new CHAR[cbBytesToRead];

		hSrcFile = CNTFSHelper::CreateFile(lpszPath, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if (INVALID_HANDLE_VALUE_NTFS == hSrcFile)
		{
			break;
		}

		if (FileSize)
		{
			FileSize->LowPart = CNTFSHelper::GetFileSize(hSrcFile, (LPDWORD)&FileSize->HighPart);
		}

		MD5Init(&context);
		SHA256_Init(&info);

		bInit = TRUE;

		bResult = CNTFSHelper::ReadFile(hSrcFile, pBuffer, cbBytesToRead, &cbBytesRead, NULL);

		do
		{
			if (bResult == FALSE || cbBytesRead == 0)
			{
				break;
			}

			SHA256_Process(&info, (const BYTE *)pBuffer, cbBytesRead);
			MD5Update(&context, (unsigned char*)pBuffer, cbBytesRead);

		} while (bResult = CNTFSHelper::ReadFile(hSrcFile, pBuffer, cbBytesToRead, &cbBytesRead, NULL));

	} while (FALSE);

	if (INVALID_HANDLE_VALUE_NTFS != hSrcFile)
	{
		CNTFSHelper::CloseHandle(hSrcFile);
		hSrcFile = INVALID_HANDLE_VALUE_NTFS;
	}

	if (pBuffer)
	{
		delete pBuffer;
	}

	if (bInit)
	{
		MD5Final(DigestMd5, &context);

		::StringCchPrintf(pszMd5, cchMd5,
			L"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
			DigestMd5[0], DigestMd5[1], DigestMd5[2], DigestMd5[3],
			DigestMd5[4], DigestMd5[5], DigestMd5[6], DigestMd5[7],
			DigestMd5[8], DigestMd5[9], DigestMd5[10], DigestMd5[11],
			DigestMd5[12], DigestMd5[13], DigestMd5[14], DigestMd5[15]);

		SHA256_Close(&info, DigestSha256);

		::StringCchPrintf(pszSha256, cchSha256,
			L"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
			DigestSha256[0], DigestSha256[1], DigestSha256[2], DigestSha256[3],
			DigestSha256[4], DigestSha256[5], DigestSha256[6], DigestSha256[7],
			DigestSha256[8], DigestSha256[9], DigestSha256[10], DigestSha256[11],
			DigestSha256[12], DigestSha256[13], DigestSha256[14], DigestSha256[15],
			DigestSha256[16], DigestSha256[17], DigestSha256[18], DigestSha256[19],
			DigestSha256[20], DigestSha256[21], DigestSha256[22], DigestSha256[23],
			DigestSha256[24], DigestSha256[25], DigestSha256[26], DigestSha256[27],
			DigestSha256[28], DigestSha256[29], DigestSha256[30], DigestSha256[31]
		);

		bRetValue = TRUE;
	}

	return bRetValue;
}

// ntfsutil.exe /dumpfile [FilePath1] [FilePath2]
// ntfsutil.exe /filehash [FilePath] 
// ntfsutil.exe /filelist [FilePath] 
// ntfsutil.exe /filelist /r [FilePath] /output [output_file_path]
BOOL		CxNtfsUtil::StartAction(X_NTFSPARSER_OPTION&	Option, OUT Json::Value& result)
{
	BOOL		bResult = FALSE;

	if (Option.Command == L"dumpfile")
	{
		bResult = OnDumpFileCommand(Option, result);
	}
	else if (Option.Command == L"filehash")
	{
		bResult = OnFileHashCommand(Option, result);
	}
	else if (Option.Command == L"filelist")
	{

	}
	else if (Option.Command == L"fileexist")
	{
		bResult = OnFileExistCommand(Option, result);
	}
	else {
		result["command"] = WideToAnsi(Option.Command.c_str());
		result["success"] = false;
		result["msg"] = "UNKNOWN_COMMAND";
	}

FINAL:

	return bResult;
}


BOOL		CxNtfsUtil::xDumpFile(IN LPCWSTR lpszPath, IN LPCWSTR lpszDumpPath, IN BOOL FailIfExists)
{
	CNTFSHelper::NTFS_HANDLE hSrcFile = INVALID_HANDLE_VALUE_NTFS;
	HANDLE		hDumpFile = INVALID_HANDLE_VALUE;
	BOOL		bRetValue = FALSE;
	CHAR*		pBuffer = NULL;
	DWORD		cbBytesRead = 0;
	DWORD		cbBytesToRead = 1024;
	DWORD		cbBytesWritten = 0;
	BOOL		bResult = FALSE;

	if (NULL == lpszPath)
	{
		return bRetValue;
	}

	do
	{
		pBuffer = new CHAR[cbBytesToRead];

		if (FailIfExists)
		{
			hDumpFile = ::CreateFile(lpszDumpPath, GENERIC_WRITE, 0, NULL, CREATE_NEW, 0, 0);
		}
		else {
			hDumpFile = ::CreateFile(lpszDumpPath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, 0);
		}

		if (hDumpFile == INVALID_HANDLE_VALUE)
		{
			break;
		}

		hSrcFile = CNTFSHelper::CreateFile(lpszPath, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if (INVALID_HANDLE_VALUE_NTFS == hSrcFile)
		{
			break;
		}

		bResult = CNTFSHelper::ReadFile(hSrcFile, pBuffer, cbBytesToRead, &cbBytesRead, NULL);

		do
		{
			if (bResult == FALSE || cbBytesRead == 0)
			{
				break;
			}

			bResult = ::WriteFile(hDumpFile, pBuffer, cbBytesRead, &cbBytesWritten, NULL);
			if (bResult == FALSE)
			{
				break;
			}

			bRetValue = TRUE;
		} while (bResult = CNTFSHelper::ReadFile(hSrcFile, pBuffer, cbBytesToRead, &cbBytesRead, NULL));

	} while (FALSE);

	if (INVALID_HANDLE_VALUE_NTFS != hSrcFile)
	{
		CNTFSHelper::CloseHandle(hSrcFile);
		hSrcFile = INVALID_HANDLE_VALUE_NTFS;
	}

	if (hDumpFile != INVALID_HANDLE_VALUE)
	{
		::CloseHandle(hDumpFile);
	}

	if (pBuffer)
	{
		delete pBuffer;
	}

	return bRetValue;
}

BOOL	CxNtfsUtil::xPathFileExists(const WCHAR* pszFilePath, OPTIONAL WIN32_FIND_DATAW* pFindData)
{
	WIN32_FIND_DATAW		FindData = { 0, };

	CNTFSHelper::NTFS_HANDLE hFind = INVALID_HANDLE_VALUE_NTFS;

	hFind = CNTFSHelper::FindFirstFile(pszFilePath, &FindData);
	if (hFind == INVALID_HANDLE_VALUE_NTFS)
	{
		return FALSE;
	}

	CNTFSHelper::FindClose(hFind);

	if (pFindData)
	{
		*pFindData = FindData;
	}

	return TRUE;
}

string		CxNtfsUtil::WideToAnsi(LPCWSTR szSrcWStr, UINT uCodePage)
{
	string		result;

	if (NULL == szSrcWStr)	return NULL;

	LPSTR	pszDestStr = NULL;
	INT		nDestSize = 0;

	// Get ANSI Size
	nDestSize = WideCharToMultiByte(uCodePage, 0, szSrcWStr, -1, pszDestStr, 0, NULL, NULL);
	if (0 != nDestSize)
	{
		pszDestStr = new CHAR[nDestSize];
	}
	else
	{
		pszDestStr = NULL;
	}

	if (NULL != pszDestStr)
	{
		if (0 == WideCharToMultiByte(uCodePage, 0, szSrcWStr, -1,
			pszDestStr, nDestSize, NULL, NULL))
		{
			pszDestStr = NULL;
		}
		else
		{
			// do nothing
		}
	}
	else
	{
		// do nothing
	}

FINAL:

	if (pszDestStr)
	{
		result = pszDestStr;
		delete pszDestStr;
	}

	return	result;
}

INT g_nCount2 = 0;

// �ش� ��γ����� \�� ������ ����.
//
// ���� Win32 API ���·� ����ϸ�,
// CNTFSHelper::FindFirstFile���� Inode�� ã�� ������ �ִµ�,
// �� �������� I/O�� ���� �ɷ� ���ϰ� �ִ�.
// �׷��� bFastAccessByInode�� TRUE�� �ϸ�, CNTFSHelper�� Ȯ�� API�� ����Ѵ�.
// Ȯ�� API���, Inode ������ �����Ͽ�, Inode�� ã�� ������ Skip�ϵ��� �ϴ� ���̴�.
VOID	CxNtfsUtil::PrintDirectory(IN LPCWSTR lpszPath, IN BOOL bRecurse, IN BOOL bFastAccessByInode, OPTIONAL IN CNTFSHelper::LPST_INODEDATA pstInodeData, OPTIONAL IN CNTFSHelper::LPST_INODE_CACHE pstInodeCache)
{
	PWCHAR						lpszPathAlloc = NULL;
	INT							nCchLength = 0;
	INT							nCchRemain = 0;
	CNTFSHelper::NTFS_HANDLE	hFind = INVALID_HANDLE_VALUE_NTFS;
	WIN32_FIND_DATA				stData = { 0, };
	BOOL						bDotDirectory = FALSE;

	// �ӵ� ����� ���� �߰� Data
	CNTFSHelper::ST_INODEDATA	stInodeData = { 0, };

	// http://msdn.microsoft.com/en-us/library/windows/desktop/aa365247(v=vs.85).aspx
	// �� ������ File system���� �ִ� ���̴� 32767 �����̴�.
	// �̴�,
	// C:\component\component\component\...
	// �� ���̰� 32767�� �ִ밪�̶� ���̴�.
	// �ϴ�, �̰������� 1024 ���̸� �������.
	// component�� ���̴� MAX_PATH�� ������ ���´�.
	// ���� 32767 ���̷� �����Ϸ���, naming a file, ��, \\?\�� ������ �ϴµ�,
	// �̰������� �ش� �κ��� ������� �ʴ��� �����ȴ�.
	lpszPathAlloc = (PWCHAR)malloc(sizeof(WCHAR) * 1024);
	if (NULL == lpszPath)
	{
		goto FINAL;
	}
	memset(lpszPathAlloc, 0, sizeof(WCHAR) * 1024);

	StringCchCopyW(lpszPathAlloc, 1024, lpszPath);

	if (TEXT('\0') != lpszPathAlloc[3])
	{
		// C:\ �̿��� ��쿡�� ���� \�� �ٿ��ش�.
		StringCchCatW(lpszPathAlloc, 1024, TEXT("\\"));
	}

	// ���̸� ���Ѵ�.
	// ��,
	// C:\abc �� ���� ���,
	// C:\abc\
	// �� ���� ����, ��, 7�� ������.
	nCchLength = wcslen(lpszPathAlloc);
	nCchRemain = 1024 - nCchLength;
	if (nCchLength < 2)
	{
		goto FINAL;
	}

	if (FAILED(StringCchCat(lpszPathAlloc, 1024, TEXT("*"))))
	{
		goto FINAL;
	}

	// ���� *�� ���� ������ �����Ѵ�.
	if (FALSE == bFastAccessByInode)
	{
		// Win32 API ����� ȣ��
		if (NULL == pstInodeCache)
		{
			// FindFirstFile ���ο� Inode ã�� ������ ����,
			// �� �Լ��� �ӵ��� ������ �� �ִ�.
			hFind = CNTFSHelper::FindFirstFile(lpszPathAlloc, &stData);
		}
		else
		{
			// Cache�� ����ϴ� ���,...
			hFind = CNTFSHelper::FindFirstFileExt(lpszPathAlloc, &stData, NULL, pstInodeCache);
		}
	}
	else
	{
		// Inode�� ����Ͽ� �����ϵ��� �Ѵ�.
		if (NULL != pstInodeData)
		{
			hFind = CNTFSHelper::FindFirstFileByInodeExt(lpszPathAlloc, pstInodeData, TRUE, &stInodeData, &stData, NULL, pstInodeCache);
		}
		else
		{
			// Inode�� ����Ͽ� �����ض�� �ϸ鼭,
			// Inode ������ ���� ������ ���� ������� �����Ѵ�.
			// (PrintDirectory�� �� ó�� ȣ���Ҷ��� �����)
			hFind = CNTFSHelper::FindFirstFileWithInodeExt(lpszPathAlloc, &stData, &stInodeData, NULL, pstInodeCache);
		}
	}

	if (INVALID_HANDLE_VALUE_NTFS == hFind)
	{
		goto FINAL;
	}

	if (FAILED(StringCchCopy(&lpszPathAlloc[nCchLength], nCchRemain, stData.cFileName)))
	{
		goto FINAL;
	}

	if (FILE_ATTRIBUTE_DIRECTORY == (stData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
	{
		// Directory�� ���,...
		// ���ȣ������.

		if (FILE_ATTRIBUTE_REPARSE_POINT == (stData.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT))
		{
			// ���� Reparse Point���,..
			_tprintf(TEXT("[REPARSE]"));
		}
		else
		{
			// Reparse Point�� �ƴ϶��, ���ȣ��� �����Ѵ�.
			if (TRUE == bRecurse)
			{
				bDotDirectory = FALSE;
				if (L'.' == stData.cFileName[0])
				{
					if ((L'.' == stData.cFileName[1]) && (L'\0' == stData.cFileName[2]))
					{
						// .. ���
						bDotDirectory = TRUE;
					}
					else if (L'\0' == stData.cFileName[1])
					{
						// . ���
						bDotDirectory = TRUE;
					}
				}

				if (FALSE == bDotDirectory)
				{
					if (FALSE == bFastAccessByInode)
					{
						PrintDirectory(lpszPathAlloc, bRecurse, FALSE, NULL, pstInodeCache);
					}
					else
					{
						PrintDirectory(lpszPathAlloc, bRecurse, TRUE, &stInodeData, pstInodeCache);
					}
				}
			}
		}
	}

	g_nCount2++;
	_tprintf(TEXT("[%.6d] %s\r\n"), g_nCount2, lpszPathAlloc);

	for (;;)
	{
		if (FALSE == bFastAccessByInode)
		{
			// ���� Win32 API ������ ȣ��
			if (FALSE == CNTFSHelper::FindNextFile(hFind, &stData))
			{
				break;
			}
		}
		else
		{
			// Inode ���� ��û
			if (FALSE == CNTFSHelper::FindNextFileWithInodeExt(hFind, &stData, &stInodeData))
			{
				break;
			}
		}

		StringCchCopy(&lpszPathAlloc[nCchLength], nCchRemain, stData.cFileName);

		if (FILE_ATTRIBUTE_DIRECTORY == (stData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
		{
			// Directory�� ���,...
			// ���ȣ������.

			if (FILE_ATTRIBUTE_REPARSE_POINT == (stData.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT))
			{
				// ���� Reparse Point���,..
				_tprintf(TEXT("[REPARSE]"));
			}
			else
			{
				// Reparse Point�� �ƴ϶��, ���ȣ��� �����Ѵ�.
				if (TRUE == bRecurse)
				{
					bDotDirectory = FALSE;
					if (L'.' == stData.cFileName[0])
					{
						if ((L'.' == stData.cFileName[1]) && (L'\0' == stData.cFileName[2]))
						{
							// .. ���
							bDotDirectory = TRUE;
						}
						else if (L'\0' == stData.cFileName[1])
						{
							// . ���
							bDotDirectory = TRUE;
						}
					}

					if (FALSE == bDotDirectory)
					{
						if (FALSE == bFastAccessByInode)
						{
							PrintDirectory(lpszPathAlloc, bRecurse, FALSE, NULL, pstInodeCache);
						}
						else
						{
							PrintDirectory(lpszPathAlloc, bRecurse, TRUE, &stInodeData, pstInodeCache);
						}
					}
				}
			}
		}

		g_nCount2++;
		_tprintf(TEXT("[%.6d] %s\r\n"), g_nCount2, lpszPathAlloc);
	}

FINAL:

	if (NULL != lpszPathAlloc)
	{
		free(lpszPathAlloc);
		lpszPathAlloc = NULL;
	}

	if (INVALID_HANDLE_VALUE_NTFS != hFind)
	{
		CNTFSHelper::FindClose(hFind);
		hFind = INVALID_HANDLE_VALUE_NTFS;
	}
	return;
}