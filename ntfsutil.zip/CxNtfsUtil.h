#pragma once

#include <windows.h>

#include <string>
using namespace std;

typedef struct _X_NTFSPARSER_OPTION
{
	wstring		Command;
	ULONG		Flag;
	wstring		FilePath1;
	wstring		FilePath2;
	wstring		OutputFile;
} X_NTFSPARSER_OPTION, *PX_NTFSPARSER_OPTION;

#define			X_NTFS_OPTION_RECURSIVE_ENUMERATION		1
#define			X_NTFS_OPTION_OUTPUT_FILE				2
#define			X_NTFS_OPTION_OUTPUT_SPLIT_FILE			4
#define			X_NTFS_OPTION_FAIL_IF_EXISTS			8

#define			X_SHA256_LENGTH				65
#define			X_MD5_LENGTH				33

#include "NTFSHelper.h"
#include "json/json.h"

class CxNtfsUtil
{
public:
	CxNtfsUtil();
	~CxNtfsUtil();

	BOOL		StartAction(X_NTFSPARSER_OPTION&	Option, OUT Json::Value& result);

	BOOL		OnDumpFileCommand(X_NTFSPARSER_OPTION&	Option, OUT Json::Value& result);
	BOOL		OnFileHashCommand(X_NTFSPARSER_OPTION&	Option, OUT Json::Value& result);
	BOOL		OnFileExistCommand(X_NTFSPARSER_OPTION&	Option, OUT Json::Value& result);
	BOOL		OnFileListCommand(X_NTFSPARSER_OPTION&	Option, OUT Json::Value& result);

protected:
	BOOL		xPathFileExists(const WCHAR* pszFilePath, OPTIONAL WIN32_FIND_DATAW* FindData = NULL);
	BOOL		xDumpFile(IN LPCWSTR pszFilePath, IN LPCWSTR lpszDumpPath, IN BOOL FailIfExists = FALSE);
	BOOL		xHashFile(IN LPCWSTR pszFilePath, WCHAR* szMd5, ULONG cchMd5, WCHAR* szSha256, ULONG cchSha256, OPTIONAL LARGE_INTEGER* FileSize = NULL);
	VOID		PrintDirectory(IN LPCWSTR pszDirPath, IN BOOL bRecurse, IN BOOL bFastAccessByInode, OPTIONAL IN CNTFSHelper::LPST_INODEDATA pstInodeData, OPTIONAL IN CNTFSHelper::LPST_INODE_CACHE pstInodeCache);

	Json::Value	FileInfoToJson(const WCHAR* pszFilePath, WIN32_FIND_DATAW& FindData);

	string		WideToAnsi(LPCWSTR szSrcWStr, UINT uCodePage = CP_UTF8);
};

